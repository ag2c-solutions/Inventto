import { z } from 'zod';

export const envSchema = z.object({
  supabase: z.object({
    url: z
      .string({ error: 'VITE_SUPABASE_URL is required' })
      .min(1, 'VITE_SUPABASE_URL is required'),
    anonKey: z
      .string({ error: 'VITE_SUPABASE_ANON_KEY is required' })
      .min(1, 'VITE_SUPABASE_ANON_KEY is required')
  }),
  cloudinary: z.object({
    cloudName: z
      .string({ error: 'VITE_CLOUDINARY_NAME is required' })
      .min(1, 'VITE_CLOUDINARY_NAME is required'),
    presetName: z
      .string({ error: 'VITE_CLOUDINARY_PRESET_NAME is required' })
      .min(1, 'VITE_CLOUDINARY_PRESET_NAME is required')
  }),
  api: z.object({
    baseUrl: z
      .string({ error: 'VITE_API_BASE_URL is required' })
      .min(1, 'VITE_API_BASE_URL is required')
  })
});

export type Env = z.infer<typeof envSchema>;
